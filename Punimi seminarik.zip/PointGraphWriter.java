import javax.swing.*;
import java.util.*;
import java.awt.*;
public class PointGraphWriter extends JPanel {

   private int x_pos;
   private int y_pos;
   private int axis_length;
   private String x_label;
   private String y_label;

   private int point1;
   private int point2;
   private int point3;
   private int point4;
   private int point5;
   private int point6;

   public PointGraphWriter() {
      JFrame frame=new JFrame();
      frame.setContentPane(this);
      frame.setTitle("Point Graph Writer");
      frame.setSize(700,700);
      frame.setVisible(true);
   }
   public void paintComponent(Graphics g) {
      g.setColor(Color.black);
      g.drawLine(x_pos,y_pos,x_pos+axis_length,y_pos);//boshti x
      g.drawLine(x_pos,y_pos,x_pos,y_pos-axis_length+20);//boshti y
      
      // 1 numer i ka 1 pixela
      int distanca = 100;
      
      int nr100=y_pos-distanca;
      int nr200=y_pos-2*distanca;
      int nr300=y_pos-3*distanca;
      int nr400=y_pos-4*distanca;
      int nr500=y_pos-5*distanca;
    
      
      int vlera1 = y_pos- point1;
      int vlera2 = y_pos- point2;
      int vlera3 = y_pos - point3;
      int vlera4 = y_pos- point4;
      int vlera5 = y_pos - point5;
      int vlera6 = y_pos - point6;


           
      g.fillOval(x_pos-3,vlera1,6,6);
      g.fillOval((x_pos+axis_length)/5-3,vlera2,6,6);
      g.fillOval(((x_pos+axis_length)/5)*2-3,vlera3,6,6);
      g.fillOval(((x_pos+axis_length)/5)*3-3,vlera4,6,6);
      g.fillOval(((x_pos+axis_length)/5)*4-3,vlera5,6,6);
      g.fillOval(((x_pos+axis_length)/5)*5-3,vlera6,6,6);
      
   
      g.drawLine(x_pos,vlera1,(x_pos+axis_length)/5,vlera2);
      g.drawLine((x_pos+axis_length)/5,vlera2,(x_pos+axis_length)*2/5,vlera3);
      g.drawLine((x_pos+axis_length)*2/5,vlera3,(x_pos+axis_length)*3/5,vlera4);
      g.drawLine((x_pos+axis_length)*3/5,vlera4,(x_pos+axis_length)*4/5,vlera5);
      g.drawLine((x_pos+axis_length)*4/5,vlera5,(x_pos+axis_length)*5/5,vlera6);
      
      g.drawString("Java 1",x_pos,y_pos+15);
      g.drawString("Java 2",(x_pos+axis_length)/5,y_pos+15);
      g.drawString("Java 3",(x_pos+axis_length)*2/5,y_pos+15);
      g.drawString("Java 4",(x_pos+axis_length)*3/5,y_pos+15);
      g.drawString("Java 5",(x_pos+axis_length)*4/5,y_pos+15);
      g.drawString("Java 6",(x_pos+axis_length)*5/5-15,y_pos+15);
      
      g.drawString("100",x_pos-20,nr100);
      g.drawString("200",x_pos-20,nr200);
      g.drawString("300",x_pos-20,nr300);
      g.drawString("400",x_pos-20,nr400);
      g.drawString("500",x_pos-20,nr500);
    
      
      g.setColor(Color.RED);
      
      g.drawString(""+point1, x_pos-20,vlera1);
      g.drawString(""+point2, x_pos-20,vlera2);
      g.drawString(""+point3, x_pos-20,vlera3);
      g.drawString(""+point4, x_pos-20,vlera4);
      g.drawString(""+point5, x_pos-20,vlera5);
      g.drawString(""+point6, x_pos-20,vlera6);
      
      g.setColor(Color.BLUE);
      g.drawString(x_label,x_pos+axis_length,y_pos);
      g.drawString(y_label,x_pos,y_pos-axis_length+20);

            
     
   }

   public void setAxes(int x_pos, int y_pos, int axis_length, String x_label, String y_label) {
      this.x_pos=x_pos;
      this.y_pos=y_pos;
      this.axis_length=axis_length;  
      this.x_label=x_label;
      this.y_label=y_label;
   }
   public void setPoint1(int height) {
      this.point1=height;
   }
   public void setPoint2(int height) {
      this.point2=height;
   }
   public void setPoint3(int height) {
      this.point3=height;
   }
   public void setPoint4(int height) {
      this.point4=height;
   }
   public void setPoint5(int height) {
      this.point5=height;
   }
   public void setPoint6(int height) {
      this.point6=height;
   }
   public static void main(String[]args)
   {
      PointGraphWriter e=new PointGraphWriter();
      e.setAxes(50,600,600,"x","y");
      int scale_factor=3;
      e.setPoint1(450);
      e.setPoint2(120);
      e.setPoint3(340);
      e.setPoint4(500);
      e.setPoint5(50);
      e.setPoint6(100);
   }
   
}