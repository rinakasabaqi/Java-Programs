import javax.swing.*;
import java.awt.*;

public class Distance extends JPanel {

    String shpejtesia=JOptionPane.showInputDialog("Shkruaje nje vlere per shpejtesine fillestare:");
    String nxitimi=JOptionPane.showInputDialog("Shkruaje nje vlere per nxitimin:");
    double shpejtesiaDouble=new Double(shpejtesia).doubleValue();
    double nxitimiDouble=new Double(nxitimi).doubleValue();

    int t1=0;
    int t2=2;
    int t3=4;
    int t4=6;
    int t5=8;
    int t6=10;


    double d1 = distanca(shpejtesiaDouble,nxitimiDouble,t1);
    double d2 = distanca(shpejtesiaDouble,nxitimiDouble,t2);
    double d3 = distanca(shpejtesiaDouble,nxitimiDouble,t3);
    double d4 = distanca(shpejtesiaDouble,nxitimiDouble,t4);
    double d5 = distanca(shpejtesiaDouble,nxitimiDouble,t5);
    double d6 = distanca(shpejtesiaDouble,nxitimiDouble,t6);

    String distanca0="" + d1;
    String distanca2="" + d2;
    String distanca4="" + d3;
    String distanca6="" + d4;
    String distanca8="" + d5;
    String distanca10="" + d6;

    int width=800;
    int height=600;
    int x=width/10;//pozita e x
    int y=height-height/10;//pozita e y
    int x1=width-x-100;//perfundimi i x
    int y1=height-height/10;//perfundimi i y ne boshtin x
    int y2=height/10;//perfundimi i y ne boshtin y
    int distancaPikave=(width*10)/100; //gjersia ndermjet pikave


    int nr0_x=x;
    int nr2_x=x+distancaPikave;
    int nr4_x=x+(distancaPikave)*2;
    int nr6_x=x+(distancaPikave)*3;
    int nr8_x=x+(distancaPikave)*4;
    int nr10_x=x+(distancaPikave)*5;

    public Distance()
    {  JFrame korniza=new JFrame();
        korniza.getContentPane().add(this);
        korniza.setSize(width+width/15,height+width/15);
        korniza.setVisible(true);
        korniza.setTitle("detyra");
    }
    public void paintComponent(Graphics g)
    {
        g.setColor(Color.white);
        g.fillRect(0,0,width+width/20,height+width/20);
        g.setColor(Color.black);

        g.drawLine(x,y,x1,y1);//boshti x
        g.drawLine(x,y,x,y2);// boshti y

        // ne boshtin x
        g.fillOval(nr0_x-2,y-2,5,5);
        g.fillOval(nr2_x-2,y-2,5,5);
        g.fillOval(nr4_x-2,y-2,5,5);
        g.fillOval(nr6_x-2,y-2,5,5);
        g.fillOval(nr8_x-2,y-2,5,5);
        g.fillOval(nr10_x-2,y-2,5,5);

        g.drawString("0",nr0_x-5/2,y+width/40);
        g.drawString("2",nr2_x-5/2,y+width/40);
        g.drawString("4",nr4_x-5/2,y+width/40);
        g.drawString("6",nr6_x-5/2,y+width/40);
        g.drawString("8",nr8_x-5/2,y+width/40);
        g.drawString("10",nr10_x-5/2,y+width/40);

        //ne boshtin y
        g.fillOval(x-2,y-(int)d2-2,5,5);
        g.fillOval(x-2,y-(int)d3-2,5,5);
        g.fillOval(x-2,y-(int)d4-2,5,5);
        g.fillOval(x-2,y-(int)d5-2,5,5);
        g.fillOval(x-2,y-(int)d6-2,5,5);


        g.drawString(distanca10,x-2*width/40,y-(int)d6-2);
        g.drawString(distanca8,x-2*height/40,y-(int)d5-2);
        g.drawString(distanca6,x-2*height/40,y-(int)d4-2);
        g.drawString(distanca4,x-2*height/40,y-(int)d3-2);
        g.drawString(distanca2,x-2*height/40,y-(int)d2-2);

        g.setColor(Color.gray.darker());
        g.fillOval(nr0_x-2,y-(int)d1-2,5,5);
        g.fillOval(nr2_x-2,y-(int)d2-2,5,5);
        g.fillOval(nr4_x-2,y-(int)d3-2,5,5);
        g.fillOval(nr6_x-2,y-(int)d4-2,5,5);
        g.fillOval(nr8_x-2,y-(int)d5-2,5,5);
        g.fillOval(nr10_x-2,y-(int)d6-2,5,5);

        g.setColor(Color.magenta.darker());
        g.drawLine(nr0_x,y,nr2_x,y-(int)d2);
        g.drawLine(nr2_x,y-(int)d2,nr4_x,y-(int)d3);
        g.drawLine(nr4_x,y-(int)d3,nr6_x,y-(int)d4);
        g.drawLine(nr6_x,y-(int)d4,nr8_x,y-(int)d5);
        g.drawLine(nr8_x,y-(int)d5,nr10_x,y-(int)d6);
        repaint();

    }

    public double distanca(double shpejtesia,double nxitimi, int koha)
    {
        double d = (shpejtesia*koha)+ (nxitimi* Math.pow(koha,2))/2;
        return d;
    }

    public static void main(String[] args) {
        new Distance();
    }
}